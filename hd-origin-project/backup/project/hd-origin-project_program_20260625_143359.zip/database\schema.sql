﻿CREATE TABLE IF NOT EXISTS received_items (
    id BIGSERIAL PRIMARY KEY,
    received_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    type TEXT,
    amount NUMERIC(12,2),
    name TEXT,
    deal_date DATE,
    memo TEXT,
    payload JSONB NOT NULL
);
